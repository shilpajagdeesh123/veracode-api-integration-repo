# Veracode Enterprise PowerShell V1

This source package is designed for organizations that prohibit Python and
custom executable binaries but permit trusted, signed PowerShell.

## Important

This package is unsigned. Because the target environment uses:

```text
MachinePolicy = AllSigned
```

your organization must sign all `.ps1` and `.psm1` files with a trusted
enterprise code-signing certificate before developers can run it.

No administrator installation is required after the signed package is approved.

## Layout

```text
repository/
├── .github/
│   ├── agents/
│   └── skills/
└── veracode-enterprise/
    ├── modules/
    ├── scripts/
    ├── config/
    ├── docs/
    ├── run-veracode.bat
    └── verify-signatures.bat
```

## Developer prompt

```text
Start Veracode API scan
```
