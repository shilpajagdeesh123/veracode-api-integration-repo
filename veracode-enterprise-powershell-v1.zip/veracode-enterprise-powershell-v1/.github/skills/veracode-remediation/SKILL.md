---
name: veracode-remediation
description: Analyze the latest raw Veracode results.json and apply evidence-driven remediation.
---

# Veracode Remediation Skill

## Source of truth

Use only:

`.github/Output/<target>/<latest-successful-scan>/results.json`

`results.csv` is for readability only.

## Finding workflow

For each finding:

1. Capture finding ID, CWE, severity, module, reported file, line, and method.
2. Map the Veracode-reported path to an exact repository path.
3. Identify the security-sensitive sink.
4. Trace the relevant source-to-sink data flow.
5. Identify the root cause.
6. Apply the smallest safe remediation.
7. Build/test the affected scope.
8. Record evidence in `remediation-report.md`.

If the exact path or safe fix cannot be determined, use:

`MANUAL_REVIEW_REQUIRED`

Never guess a source path or fabricate a solution.
