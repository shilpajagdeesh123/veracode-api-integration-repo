---
name: veracode-scan
description: Run the enterprise signed-PowerShell Veracode Pipeline Scan workflow.
---

# Veracode Scan Skill

Primary prompt:

`Start Veracode API scan`

Run from repository root:

```bat
cd /d veracode-enterprise
run-veracode.bat
```

The package uses only signed PowerShell scripts and built-in Windows tools.

Do not:
- request HMAC credentials in chat;
- override `AllSigned`;
- call unsigned PowerShell files;
- execute custom binaries.

The terminal scanner prompts for the HMAC API ID/key when the secret file is
missing, creates the secret file, packages the selected target, runs the REST
Pipeline Scan, saves the raw response as `results.json`, and creates `results.csv`.
