[CmdletBinding()]
param([Parameter(Mandatory)][string]$ToolHome)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$files = @(
    Get-ChildItem -LiteralPath (Join-Path $ToolHome "scripts") -Filter *.ps1 -File
    Get-ChildItem -LiteralPath (Join-Path $ToolHome "modules") -Filter *.psm1 -File
)

$invalid = @()

foreach ($file in $files) {
    $signature = Get-AuthenticodeSignature -LiteralPath $file.FullName
    Write-Host ("{0}: {1}" -f $file.Name, $signature.Status)
    if ($signature.Status -ne "Valid") {
        $invalid += $file.FullName
    }
}

if ($invalid.Count -gt 0) {
    Write-Error "One or more PowerShell files do not have a valid trusted signature."
    exit 10
}

Write-Host "All PowerShell scripts and modules have valid signatures." -ForegroundColor Green
exit 0
