[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ToolHome,
    [Parameter(Mandatory)][string]$CertificateThumbprint,
    [Parameter(Mandatory)][string]$TimestampServer
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$certificate = Get-Item -LiteralPath "Cert:\CurrentUser\My\$CertificateThumbprint"

$files = @(
    Get-ChildItem -LiteralPath (Join-Path $ToolHome "scripts") -Filter *.ps1 -File
    Get-ChildItem -LiteralPath (Join-Path $ToolHome "modules") -Filter *.psm1 -File
)

foreach ($file in $files) {
    $result = Set-AuthenticodeSignature `
        -LiteralPath $file.FullName `
        -Certificate $certificate `
        -TimestampServer $TimestampServer `
        -HashAlgorithm SHA256

    if ($result.Status -ne "Valid") {
        throw "Signing failed for $($file.FullName): $($result.StatusMessage)"
    }
    Write-Host "Signed: $($file.Name)"
}
