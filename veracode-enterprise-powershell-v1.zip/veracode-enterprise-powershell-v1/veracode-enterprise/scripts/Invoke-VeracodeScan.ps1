[CmdletBinding()]
param([Parameter(Mandatory)][string]$ToolHome)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$repositoryRoot = Split-Path -Parent $ToolHome
$config = Get-Content -LiteralPath (Join-Path $ToolHome "config\scanner.json") -Raw | ConvertFrom-Json

Import-Module (Join-Path $ToolHome "modules\Configuration.psm1") -Force
Import-Module (Join-Path $ToolHome "modules\Packaging.psm1") -Force
Import-Module (Join-Path $ToolHome "modules\PipelineClient.psm1") -Force
Import-Module (Join-Path $ToolHome "modules\Reports.psm1") -Force

$secret = Get-OrCreateVeracodeSecrets -ToolHome $ToolHome
$hostName = "api.veracode.com"

Write-Host ""
Write-Host "Veracode Pipeline Scan" -ForegroundColor Cyan
Write-Host "1. PROJECT"
Write-Host "2. MODULE"
Write-Host "3. EXISTING VERACODE PACKAGE"

$mode = Read-Host "Select scan mode"

$artifact = $null
$targetName = $null

if ($mode -eq "3") {
    $path = (Read-Host "Enter full path to ZIP/JAR/WAR/EAR").Trim('"')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Artifact not found: $path"
    }
    $artifact = (Resolve-Path -LiteralPath $path).Path
    $targetName = [IO.Path]::GetFileNameWithoutExtension($artifact)
}
else {
    $targets = @()

    Get-ChildItem -LiteralPath $repositoryRoot -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Name -in @("pom.xml", "angular.json", "package.json") -or
            $_.Extension.ToLowerInvariant() -in @(".cbl", ".cob", ".cobol", ".cpy", ".pco", ".jcl", ".pli", ".pl1")
        } |
        ForEach-Object {
            $directory = $_.Directory.FullName
            if ($directory -notlike "$ToolHome*") {
                $targets += $directory
            }
        }

    $targets = @($targets | Sort-Object -Unique)
    if ($targets.Count -eq 0) {
        throw "No Java, Angular/Node, or mainframe target was found."
    }

    for ($i = 0; $i -lt $targets.Count; $i++) {
        Write-Host ("[{0}] {1}" -f ($i + 1), $targets[$i])
    }

    [int]$selection = Read-Host "Select project/module"
    if ($selection -lt 1 -or $selection -gt $targets.Count) {
        throw "Invalid target selection."
    }

    $target = $targets[$selection - 1]
    $targetName = Split-Path -Leaf $target

    $date = Get-Date -Format "yyyy-MM-dd"
    $outputBase = Join-Path $repositoryRoot ".github\Output\$targetName\$date"
    New-Item -ItemType Directory -Path $outputBase -Force | Out-Null
    $packageDirectory = Join-Path $outputBase "package"
    New-Item -ItemType Directory -Path $packageDirectory -Force | Out-Null

    if (Test-Path -LiteralPath (Join-Path $target "pom.xml")) {
        $candidate = Get-ChildItem -LiteralPath (Join-Path $target "target") -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in @(".jar", ".war", ".ear") } |
            Sort-Object Length -Descending |
            Select-Object -First 1

        if ($null -eq $candidate) {
            throw "No prebuilt Java artifact found. Build it first or use Existing Package mode."
        }
        $artifact = $candidate.FullName
    }
    else {
        $artifact = Join-Path $packageDirectory "$targetName.zip"
        New-ZipFromDirectory `
            -SourceDirectory $target `
            -OutputFile $artifact `
            -AllowedExtensions @(".ts", ".tsx", ".js", ".jsx", ".html", ".css", ".json", ".yml", ".yaml", ".cbl", ".cob", ".cobol", ".cpy", ".pco", ".jcl", ".pli", ".pl1") `
            -ExcludedDirectories @(".git", ".github", "node_modules", "dist", "coverage", "target") | Out-Null
    }
}

$date = Get-Date -Format "yyyy-MM-dd"
$outputDirectory = Join-Path $repositoryRoot ".github\Output\$targetName\$date"
if (Test-Path -LiteralPath (Join-Path $outputDirectory "results.json")) {
    $outputDirectory = Join-Path $outputDirectory (Get-Date -Format "HHmmss")
}
New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null

$file = Get-Item -LiteralPath $artifact
$hash = (Get-FileHash -LiteralPath $artifact -Algorithm SHA256).Hash.ToLowerInvariant()

$create = Invoke-VeracodeJsonRequest `
    -Method POST `
    -HostName $hostName `
    -RequestTarget "/pipeline_scan/v1/scans" `
    -ApiId $secret.api_id `
    -ApiKey $secret.api_key `
    -Body @{
        binary_name = $file.Name
        binary_size = [long]$file.Length
        binary_hash = $hash
        project_name = $targetName
        dev_stage = $config.developmentStage
    }

$scanId = [string]$create.scan_id
$segmentCount = [int]$create.binary_segments_expected

if ([string]::IsNullOrWhiteSpace($scanId) -or $segmentCount -lt 1) {
    throw "Invalid Pipeline Scan configuration response."
}

$segmentDirectory = Join-Path $outputDirectory "segments"
$segments = @(Split-BinaryFile -InputFile $artifact -SegmentCount $segmentCount -OutputDirectory $segmentDirectory)

for ($i = 0; $i -lt $segments.Count; $i++) {
    Write-Host ("Uploading segment {0}/{1}" -f ($i + 1), $segments.Count)
    Invoke-VeracodeSegmentUpload `
        -HostName $hostName `
        -RequestTarget "/pipeline_scan/v1/scans/$scanId/segments/$i" `
        -ApiId $secret.api_id `
        -ApiKey $secret.api_key `
        -SegmentFile $segments[$i] | Out-Null
}

Invoke-VeracodeJsonRequest `
    -Method PUT `
    -HostName $hostName `
    -RequestTarget "/pipeline_scan/v1/scans/$scanId" `
    -ApiId $secret.api_id `
    -ApiKey $secret.api_key `
    -Body @{ scan_status = "STARTED" } | Out-Null

$deadline = (Get-Date).AddMinutes([int]$config.maxScanMinutes)
do {
    Start-Sleep -Seconds ([int]$config.pollSeconds)
    $details = Invoke-VeracodeJsonRequest `
        -Method GET `
        -HostName $hostName `
        -RequestTarget "/pipeline_scan/v1/scans/$scanId" `
        -ApiId $secret.api_id `
        -ApiKey $secret.api_key

    $status = [string]$details.scan_status
    Write-Host "Scan status: $status"

    if ($status -in @("ERROR", "FAILED", "CANCELLED", "CANCELED")) {
        throw "Pipeline Scan failed with status: $status"
    }
}
while ($status -ne "SUCCESS" -and (Get-Date) -lt $deadline)

if ($status -ne "SUCCESS") {
    throw "Pipeline Scan timed out."
}

# Use Invoke-WebRequest so the response body can be saved without JSON re-serialization.
$requestTarget = "/pipeline_scan/v1/scans/$scanId/findings"
$authorization = New-VeracodeAuthorizationHeader `
    -ApiId $secret.api_id `
    -ApiKey $secret.api_key `
    -HostName $hostName `
    -RequestTarget $requestTarget `
    -Method GET

$response = Invoke-WebRequest `
    -Uri "https://$hostName$requestTarget" `
    -Headers @{ Authorization = $authorization; Accept = "application/json" } `
    -UseBasicParsing

$resultsJson = Join-Path $outputDirectory "results.json"
[IO.File]::WriteAllText($resultsJson, $response.Content, [Text.UTF8Encoding]::new($false))

Convert-ResultsJsonToCsv `
    -ResultsJson $resultsJson `
    -OutputCsv (Join-Path $outputDirectory "results.csv")

@{
    pipeline_scan_status = "SUCCESS"
    official_veracode_policy_status = "NOT_EVALUATED"
    scan_id = $scanId
    target = $targetName
    artifact = $artifact
    binary_hash_sha256 = $hash
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputDirectory "scan-status.json") -Encoding UTF8

Remove-Item -LiteralPath $segmentDirectory -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Pipeline Scan completed successfully." -ForegroundColor Green
Write-Host "Output: $outputDirectory"
exit 0
