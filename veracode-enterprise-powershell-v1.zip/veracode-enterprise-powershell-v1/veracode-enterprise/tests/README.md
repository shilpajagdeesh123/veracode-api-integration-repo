# Tests

Run only after the package has been signed:

```bat
verify-signatures.bat
```

Functional pilot tests should cover:

1. Missing secret-file credential prompt.
2. Invalid HMAC key rejection.
3. Existing-package scan.
4. Angular/Node source package.
5. Mainframe/COBOL source package.
6. Raw `results.json` preservation.
7. CSV generation.
8. Same-day timestamp output.
9. Proxy/TLS inspection.
10. Re-scan after remediation.
