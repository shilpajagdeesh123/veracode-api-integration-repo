# Installation

## Requirements

- Windows PowerShell 5.1 or approved PowerShell 7.
- Corporate `MachinePolicy = AllSigned` is supported.
- All `.ps1` and `.psm1` files must be Authenticode-signed with a trusted
  enterprise code-signing certificate.
- No Python.
- No custom EXE.
- No administrator installation.
- Veracode HMAC API credentials with Pipeline Scan permissions.

## Installation

Extract at repository root:

```text
repository/
├── .github/
└── veracode-enterprise/
```

Your signing team must sign every file under:

```text
veracode-enterprise/scripts/*.ps1
veracode-enterprise/modules/*.psm1
```

After signing:

```bat
cd /d veracode-enterprise
verify-signatures.bat
run-veracode.bat
```
