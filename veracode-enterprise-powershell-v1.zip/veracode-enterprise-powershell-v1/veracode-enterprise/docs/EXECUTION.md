# Developer execution

Open the repository root in the IDE.

Select:

```text
veracode-agent
```

Prompt:

```text
Start Veracode API scan
```

The agent opens the terminal and runs:

```bat
cd /d veracode-enterprise
run-veracode.bat
```

On the first run, the terminal asks only for:

```text
Veracode HMAC API ID:
Veracode HMAC API Key:
```

The host is fixed to:

```text
api.veracode.com
```

Reports are written under:

```text
.github/Output/<target>/<date-or-timestamp>/
```

The raw Veracode response remains:

```text
results.json
```

and a readable companion is created as:

```text
results.csv
```
