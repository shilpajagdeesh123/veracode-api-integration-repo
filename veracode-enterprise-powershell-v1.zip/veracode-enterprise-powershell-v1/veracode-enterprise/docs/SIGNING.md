# Enterprise signing requirement

This package intentionally contains unsigned source scripts.

It will not run under `MachinePolicy = AllSigned` until signed by your
organization.

The signing team can use:

```powershell
.\scripts\Sign-Package.ps1 `
  -ToolHome <full-path-to-veracode-enterprise> `
  -CertificateThumbprint <approved-certificate-thumbprint> `
  -TimestampServer <approved-timestamp-server>
```

Important: `Sign-Package.ps1` itself must either be executed in the controlled
signing environment before enforcement, or signed by the signing team through
their approved tooling.

Any modification after signing invalidates the signature and requires re-signing.
