Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-FindingCollection {
    param([Parameter(Mandatory)]$Payload)

    if ($Payload -is [array]) { return @($Payload) }

    foreach ($name in @("findings", "results", "flaws")) {
        $property = $Payload.PSObject.Properties[$name]
        if ($null -ne $property -and $property.Value -is [array]) {
            return @($property.Value)
        }
    }

    $embedded = $Payload.PSObject.Properties["_embedded"]
    if ($null -ne $embedded) {
        foreach ($name in @("findings", "results", "flaws")) {
            $property = $embedded.Value.PSObject.Properties[$name]
            if ($null -ne $property -and $property.Value -is [array]) {
                return @($property.Value)
            }
        }
    }

    return @()
}

function Get-FirstPropertyValue {
    param($Object, [string[]]$Names)
    foreach ($name in $Names) {
        $property = $Object.PSObject.Properties[$name]
        if ($null -ne $property -and $null -ne $property.Value) {
            return $property.Value
        }
    }
    return ""
}

function Convert-ResultsJsonToCsv {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ResultsJson,
        [Parameter(Mandatory)][string]$OutputCsv
    )

    $payload = Get-Content -LiteralPath $ResultsJson -Raw | ConvertFrom-Json
    $findings = Get-FindingCollection -Payload $payload

    $rows = foreach ($finding in $findings) {
        [pscustomobject]@{
            issue_id = Get-FirstPropertyValue $finding @("issue_id", "issueId", "id", "flaw_id")
            cwe = Get-FirstPropertyValue $finding @("cwe_id", "cweId", "cwe")
            severity = Get-FirstPropertyValue $finding @("severity", "severity_name", "severityName")
            title = Get-FirstPropertyValue $finding @("title", "issue_type", "name", "category")
            module = Get-FirstPropertyValue $finding @("module", "module_name")
            file = Get-FirstPropertyValue $finding @("file", "file_name", "filename", "source_file")
            line = Get-FirstPropertyValue $finding @("line", "line_number", "lineNumber")
            function = Get-FirstPropertyValue $finding @("function", "procedure", "method")
            status = Get-FirstPropertyValue $finding @("status", "finding_status")
            description = Get-FirstPropertyValue $finding @("description", "issue_details", "details")
            remediation = Get-FirstPropertyValue $finding @("remediation", "recommendation", "fix")
        }
    }

    $rows | Export-Csv -LiteralPath $OutputCsv -NoTypeInformation -Encoding UTF8
}

Export-ModuleMember -Function Convert-ResultsJsonToCsv, Get-FindingCollection
