Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Import-Module (Join-Path $PSScriptRoot "VeracodeHmac.psm1") -Force

function Invoke-VeracodeJsonRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet("GET", "POST", "PUT", "DELETE")][string]$Method,
        [Parameter(Mandatory)][string]$HostName,
        [Parameter(Mandatory)][string]$RequestTarget,
        [Parameter(Mandatory)][string]$ApiId,
        [Parameter(Mandatory)][string]$ApiKey,
        $Body
    )

    $authorization = New-VeracodeAuthorizationHeader `
        -ApiId $ApiId `
        -ApiKey $ApiKey `
        -HostName $HostName `
        -RequestTarget $RequestTarget `
        -Method $Method

    $headers = @{
        Authorization = $authorization
        Accept = "application/json"
    }

    $uri = "https://$HostName$RequestTarget"

    if ($null -eq $Body) {
        return Invoke-RestMethod -Uri $uri -Method $Method -Headers $headers
    }

    $json = $Body | ConvertTo-Json -Depth 20 -Compress
    return Invoke-RestMethod `
        -Uri $uri `
        -Method $Method `
        -Headers $headers `
        -ContentType "application/json" `
        -Body $json
}

function Invoke-VeracodeSegmentUpload {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$HostName,
        [Parameter(Mandatory)][string]$RequestTarget,
        [Parameter(Mandatory)][string]$ApiId,
        [Parameter(Mandatory)][string]$ApiKey,
        [Parameter(Mandatory)][string]$SegmentFile
    )

    $authorization = New-VeracodeAuthorizationHeader `
        -ApiId $ApiId `
        -ApiKey $ApiKey `
        -HostName $HostName `
        -RequestTarget $RequestTarget `
        -Method "PUT"

    $headers = @{
        Authorization = $authorization
        Accept = "application/json"
    }

    return Invoke-RestMethod `
        -Uri "https://$HostName$RequestTarget" `
        -Method PUT `
        -Headers $headers `
        -Form @{ file = Get-Item -LiteralPath $SegmentFile }
}

Export-ModuleMember -Function Invoke-VeracodeJsonRequest, Invoke-VeracodeSegmentUpload
