Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function New-ZipFromDirectory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SourceDirectory,
        [Parameter(Mandatory)][string]$OutputFile,
        [string[]]$AllowedExtensions,
        [string[]]$ExcludedDirectories
    )

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    if (Test-Path -LiteralPath $OutputFile) {
        Remove-Item -LiteralPath $OutputFile -Force
    }

    $source = (Resolve-Path -LiteralPath $SourceDirectory).Path
    $archive = [IO.Compression.ZipFile]::Open($OutputFile, [IO.Compression.ZipArchiveMode]::Create)
    try {
        Get-ChildItem -LiteralPath $source -File -Recurse | ForEach-Object {
            $relative = $_.FullName.Substring($source.Length).TrimStart("\", "/")
            $parts = $relative -split "[\\/]"
            if ($parts | Where-Object { $ExcludedDirectories -contains $_ }) {
                return
            }

            if ($AllowedExtensions -and $AllowedExtensions.Count -gt 0) {
                if ($AllowedExtensions -notcontains $_.Extension.ToLowerInvariant()) {
                    return
                }
            }

            [IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $archive,
                $_.FullName,
                $relative.Replace("\", "/"),
                [IO.Compression.CompressionLevel]::Optimal
            ) | Out-Null
        }
    }
    finally {
        $archive.Dispose()
    }

    return $OutputFile
}

function Split-BinaryFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$InputFile,
        [Parameter(Mandatory)][int]$SegmentCount,
        [Parameter(Mandatory)][string]$OutputDirectory
    )

    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $stream = [IO.File]::OpenRead($InputFile)
    try {
        $baseSize = [math]::Floor($stream.Length / $SegmentCount)
        $remainder = $stream.Length % $SegmentCount
        $buffer = [byte[]]::new(1MB)
        $result = @()

        for ($index = 0; $index -lt $SegmentCount; $index++) {
            [long]$size = $baseSize + $(if ($index -lt $remainder) { 1 } else { 0 })
            $path = Join-Path $OutputDirectory ("segment-{0:D4}.dat" -f $index)
            $out = [IO.File]::Create($path)
            try {
                [long]$remaining = $size
                while ($remaining -gt 0) {
                    $readLength = [int][math]::Min($buffer.Length, $remaining)
                    $read = $stream.Read($buffer, 0, $readLength)
                    if ($read -le 0) { break }
                    $out.Write($buffer, 0, $read)
                    $remaining -= $read
                }
            }
            finally {
                $out.Dispose()
            }
            $result += $path
        }
        return $result
    }
    finally {
        $stream.Dispose()
    }
}

Export-ModuleMember -Function New-ZipFromDirectory, Split-BinaryFile
