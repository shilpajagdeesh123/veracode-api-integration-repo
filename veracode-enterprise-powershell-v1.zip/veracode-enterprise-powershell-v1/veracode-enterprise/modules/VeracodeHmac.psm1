Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Convert-HexToBytes {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Hex)

    if (($Hex.Length % 2) -ne 0) {
        throw "HMAC key must contain an even number of hexadecimal characters."
    }

    $bytes = [byte[]]::new($Hex.Length / 2)
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        $bytes[$i] = [Convert]::ToByte($Hex.Substring($i * 2, 2), 16)
    }
    return $bytes
}

function Convert-BytesToHex {
    [CmdletBinding()]
    param([Parameter(Mandatory)][byte[]]$Bytes)
    return ([BitConverter]::ToString($Bytes)).Replace("-", "").ToLowerInvariant()
}

function Invoke-HmacSha256 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][byte[]]$Key,
        [Parameter(Mandatory)][byte[]]$Data
    )

    $hmac = [System.Security.Cryptography.HMACSHA256]::new($Key)
    try {
        return $hmac.ComputeHash($Data)
    }
    finally {
        $hmac.Dispose()
    }
}

function New-VeracodeAuthorizationHeader {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ApiId,
        [Parameter(Mandatory)][string]$ApiKey,
        [Parameter(Mandatory)][string]$HostName,
        [Parameter(Mandatory)][string]$RequestTarget,
        [Parameter(Mandatory)][string]$Method
    )

    $timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()

    $nonce = [byte[]]::new(16)
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($nonce)
    }
    finally {
        $rng.Dispose()
    }

    $secret = Convert-HexToBytes -Hex $ApiKey
    $kNonce = Invoke-HmacSha256 -Key $secret -Data $nonce
    $kDate = Invoke-HmacSha256 -Key $kNonce -Data ([Text.Encoding]::UTF8.GetBytes($timestamp))
    $kSignature = Invoke-HmacSha256 -Key $kDate -Data ([Text.Encoding]::UTF8.GetBytes("vcode_request_version_1"))

    $canonical = "id=$ApiId&host=$HostName&url=$RequestTarget&method=$($Method.ToUpperInvariant())"
    $signature = Invoke-HmacSha256 -Key $kSignature -Data ([Text.Encoding]::UTF8.GetBytes($canonical))

    return "VERACODE-HMAC-SHA-256 id=$ApiId,ts=$timestamp,nonce=$(Convert-BytesToHex $nonce),sig=$(Convert-BytesToHex $signature)"
}

Export-ModuleMember -Function New-VeracodeAuthorizationHeader
