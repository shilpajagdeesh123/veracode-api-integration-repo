Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Read-MaskedValue {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Prompt)

    $secure = Read-Host -Prompt $Prompt -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

function Get-OrCreateVeracodeSecrets {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$ToolHome)

    $path = Join-Path $ToolHome "config\veracode-secrets.json"

    if (Test-Path -LiteralPath $path) {
        $data = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
        if (
            -not [string]::IsNullOrWhiteSpace([string]$data.api_id) -and
            -not [string]::IsNullOrWhiteSpace([string]$data.api_key)
        ) {
            return $data
        }
    }

    Write-Host ""
    Write-Host "Veracode HMAC credential setup" -ForegroundColor Cyan
    $apiId = (Read-Host "Veracode HMAC API ID").Trim()
    $apiKey = (Read-MaskedValue -Prompt "Veracode HMAC API Key").Trim()

    if ([string]::IsNullOrWhiteSpace($apiId) -or [string]::IsNullOrWhiteSpace($apiKey)) {
        throw "API ID and API key are required."
    }

    $secret = [ordered]@{
        api_id = $apiId
        api_key = $apiKey
        api_host = "api.veracode.com"
    }

    $secret | ConvertTo-Json | Set-Content -LiteralPath $path -Encoding UTF8
    Write-Host "Credential file created: $path"
    return [pscustomobject]$secret
}

Export-ModuleMember -Function Get-OrCreateVeracodeSecrets
