@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

powershell.exe -NoLogo -NoProfile -File "%TOOL_HOME%\scripts\Invoke-VeracodeScan.ps1" -ToolHome "%TOOL_HOME%"
exit /b %ERRORLEVEL%
