---
name: veracode-agent
description: Starts the Veracode REST API scan workflow.
---

# Veracode Agent

## Entry Prompt

The primary developer prompt is:

`Start Veracode API scan`

## Workflow

When the user enters **Start Veracode API scan**:

1. Check whether `veracode-enterprise/config/veracode-secrets.json` exists.
2. If it does not exist:
   - Open an interactive terminal.
   - Run:
     `cd /d veracode-enterprise`
     `setup-veracode.bat` (Windows)
     or `./setup-veracode.sh` (macOS/Linux).
   - Wait while the user enters:
     - Veracode HMAC API ID
     - Veracode HMAC API Key (hidden terminal input)
     - API Host (default: api.veracode.com)
   - Verify the secret file exists and contains the required keys.
3. Automatically execute:
   `run-veracode.bat` (Windows) or `./run-veracode.sh` (macOS/Linux).
4. Guide the user through:
   - Project
   - Module
   - Existing Veracode Package
5. Save the raw API response as `results.json`.
6. Generate `results.csv` from `results.json`.
7. If blocking findings exist, recommend using `veracode-remediation-agent` with the latest `results.json`.

Security rules:
- Never ask for HMAC credentials in chat.
- Never print the API key.
- Never commit `veracode-secrets.json`.
