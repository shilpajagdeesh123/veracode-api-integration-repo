# Veracode Remediation Skill

1. Locate the latest relevant `.github/Output/**/results.json`.
2. Parse findings only from `results.json`.
3. Map each finding to the repository source file and line where possible.
4. Create remediation evidence below `.github/remediation/<project>/src/<date>/` for mainframe or `.github/remediation/<project>/<date>/` otherwise.
5. Generate `remediation-report.md`, `changed-files.txt`, `remediation.patch`, and `validation.log`.
6. Do not expose HMAC credentials or read `veracode-secrets.json`.
