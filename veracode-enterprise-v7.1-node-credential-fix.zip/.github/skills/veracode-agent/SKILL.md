# Veracode API Scan Skill

## Trigger

Run when the user requests: `Start Veracode API scan`.

## Execution

From the repository root run:

```text
node ./veracode-enterprise-node/src/index.js
```

The process must stay in the current terminal. It performs project discovery, secure credential entry, source packaging, Veracode HMAC authentication, Pipeline Scan submission, polling, and result generation.

## Security

Never collect or echo credentials in Copilot chat. The API key is entered through a hidden terminal prompt and stored only in `veracode-enterprise-node/config/veracode-secrets.json`, which is excluded from Git.

## Outputs

Mainframe:

```text
.github/Output/<module-or-project>/src/<date-or-timestamp>/results.json
.github/Output/<module-or-project>/src/<date-or-timestamp>/results.csv
```

Other projects:

```text
.github/Output/<module-or-project>/<date-or-timestamp>/results.json
.github/Output/<module-or-project>/<date-or-timestamp>/results.csv
```
