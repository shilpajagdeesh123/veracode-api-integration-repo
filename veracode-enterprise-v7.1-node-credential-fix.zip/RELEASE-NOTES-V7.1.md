# Veracode Enterprise Node Agent V7.1

## Credential handling correction

- Removed any fixed HMAC Secret Key length assumption.
- Accepts complete even-length hexadecimal Veracode secret keys, including 128-character keys.
- Removes accidental spaces, line breaks, BOMs, and common invisible copy/paste characters.
- Validates API ID and Secret Key presence without printing either value.
- Provides clear HTTP 401 and HTTP 403 messages from Veracode.
- Keeps `results.json` as the authoritative remediation input.

## Security notice

`veracode-enterprise-node/config/veracode-secrets.json` is excluded by `.gitignore`. Never commit or share this file.
