import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createZip } from '../src/zip.js';

test('creates a valid non-empty ZIP container', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vc-node-')); fs.writeFileSync(path.join(dir, 'a.txt'), 'hello');
  const zip = path.join(dir, 'out.zip'); createZip(dir, zip, p => !p.endsWith('out.zip'));
  const data = fs.readFileSync(zip); assert.equal(data.readUInt32LE(0), 0x04034b50); assert.ok(data.length > 40);
});
