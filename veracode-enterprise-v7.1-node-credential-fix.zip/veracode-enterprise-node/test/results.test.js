import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeResults } from '../src/results.js';

test('normalizes findings and counts blocking severity', () => {
  const result = normalizeResults({ findings: [{ id: 1, severity: 'High', cwe_id: 80, file: 'src/a.cbl' }] }, 'PROJECT', 'demo', ['high']);
  assert.equal(result.finding_count, 1); assert.equal(result.blocking_finding_count, 1); assert.equal(result.findings[0].cwe, 80);
});
