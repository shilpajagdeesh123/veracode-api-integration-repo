import fs from 'node:fs';
import path from 'node:path';
import { dateStamp, isoNow, timeStamp, writeJson } from './utils.js';

function first(o, keys) { for (const k of keys) if (o && o[k] !== undefined && o[k] !== null) return o[k]; return ''; }
function extract(raw) {
  for (const k of ['findings', 'results', 'flaws']) if (Array.isArray(raw?.[k])) return raw[k];
  if (raw?._embedded) return extract(raw._embedded);
  return [];
}
export function normalizeResults(raw, scope, target, blockingSeverities = []) {
  const blocking = new Set(blockingSeverities.map(x => String(x).trim().toLowerCase())); let blockingCount = 0;
  const findings = extract(raw).map(f => {
    const severity = String(first(f, ['severity', 'severity_name', 'severityName'])); const isBlocking = blocking.has(severity.toLowerCase()); if (isBlocking) blockingCount++;
    return { issue_id: first(f, ['issue_id', 'issueId', 'id', 'flaw_id']), cwe: first(f, ['cwe_id', 'cweId', 'cwe']), severity,
      title: first(f, ['title', 'issue_type', 'name', 'category']), file: first(f, ['file', 'file_name', 'filename', 'source_file']), line: first(f, ['line', 'line_number', 'lineNumber']),
      function: first(f, ['function', 'procedure', 'method']), status: first(f, ['status', 'finding_status']), description: first(f, ['description', 'issue_details', 'details']),
      remediation: first(f, ['remediation', 'recommendation', 'fix']), scope, target, blocking: isBlocking, raw: f };
  });
  return { generated_at: isoNow(), scope, target, finding_count: findings.length, blocking_finding_count: blockingCount, findings };
}
function csvEscape(value) { const s = String(value ?? ''); return /[",\r\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s; }
export function writeCsv(file, normalized) {
  const fields = ['issue_id', 'cwe', 'severity', 'title', 'file', 'line', 'function', 'status', 'blocking', 'scope', 'target', 'description', 'remediation'];
  const rows = [fields.join(','), ...normalized.findings.map(f => fields.map(k => csvEscape(f[k])).join(','))];
  fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, rows.join('\n') + '\n');
}
export function createOutputDir(repo, name, mainframe, now = new Date()) {
  let base = path.join(repo, '.github', 'Output', name); if (mainframe) base = path.join(base, 'src');
  let output = path.join(base, dateStamp(now));
  if (fs.existsSync(path.join(output, 'results.json'))) output = path.join(output, timeStamp(now));
  fs.mkdirSync(output, { recursive: true }); return output;
}
export function writeScanOutputs({ output, raw, normalized, metadata, status }) {
  writeJson(path.join(output, 'results.json'), raw, 0o644);
  writeJson(path.join(output, 'veracode-findings.json'), normalized, 0o644);
  writeCsv(path.join(output, 'results.csv'), normalized);
  writeCsv(path.join(output, 'veracode-findings.csv'), normalized);
  writeJson(path.join(output, 'scan-metadata.json'), metadata, 0o644);
  writeJson(path.join(output, 'scan-status.json'), status, 0o644);
}
