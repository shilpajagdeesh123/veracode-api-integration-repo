import path from 'node:path';
import { existsDir, existsFile } from './utils.js';

export function locatePaths(start = process.cwd()) {
  let current = path.resolve(start);
  while (true) {
    const home = path.join(current, 'veracode-enterprise-node');
    if (existsFile(path.join(home, 'package.json')) && existsDir(path.join(home, 'config'))) return { home, repo: current };
    if (existsFile(path.join(current, 'package.json')) && existsDir(path.join(current, 'config')) && path.basename(current) === 'veracode-enterprise-node') {
      return { home: current, repo: path.dirname(current) };
    }
    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error('Repository root not found: expected veracode-enterprise-node/package.json');
}
