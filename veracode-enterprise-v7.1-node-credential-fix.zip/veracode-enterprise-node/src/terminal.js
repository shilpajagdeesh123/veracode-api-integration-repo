import readline from 'node:readline';

export function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(`${question}: `, answer => { rl.close(); resolve(answer.trim()); }));
}

export async function choose(title, options) {
  console.log(`\n${title}`);
  options.forEach((o, i) => console.log(`[${i + 1}] ${o}`));
  while (true) {
    const value = await ask('Selection');
    const index = Number.parseInt(value, 10) - 1;
    if (Number.isInteger(index) && index >= 0 && index < options.length) return index;
    console.log('Enter a valid number.');
  }
}

export function readSecret(promptText) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    return ask(promptText);
  }
  return new Promise((resolve, reject) => {
    const stdin = process.stdin;
    let value = '';
    process.stdout.write(`${promptText}: `);
    readline.emitKeypressEvents(stdin);
    const previousRaw = stdin.isRaw;
    stdin.setRawMode(true);
    stdin.resume();
    const cleanup = () => {
      stdin.off('keypress', onKey);
      stdin.setRawMode(Boolean(previousRaw));
      stdin.pause();
    };
    const onKey = (str, key) => {
      if (key?.ctrl && key.name === 'c') { cleanup(); process.stdout.write('\n'); reject(new Error('Credential entry cancelled')); return; }
      if (key?.name === 'return' || key?.name === 'enter') { cleanup(); process.stdout.write('\n'); resolve(value.trim()); return; }
      if (key?.name === 'backspace') { value = value.slice(0, -1); return; }
      if (!key?.ctrl && !key?.meta && str) value += str;
    };
    stdin.on('keypress', onKey);
  });
}
