import crypto from 'node:crypto';

function hm(key, data) {
  return crypto.createHmac('sha256', key).update(data).digest();
}

function normalizeHexSecret(value) {
  return String(value ?? '')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .replace(/\s+/g, '')
    .trim();
}

function decodeSecret(value) {
  const cleaned = normalizeHexSecret(value);
  if (!cleaned) throw new Error('HMAC API key is required.');

  // Veracode HMAC secret keys are represented as hexadecimal. Avoid a fixed
  // length assumption, but reject an unusable value before generating a bad
  // signature. This accepts current and future valid even-length key sizes.
  if (!/^[0-9a-f]+$/i.test(cleaned) || cleaned.length % 2 !== 0) {
    throw new Error('The saved HMAC API key contains an invalid or incomplete character. Re-enter the complete Secret Key from Veracode.');
  }
  return Buffer.from(cleaned, 'hex');
}

export function authorizationHeader({ apiId, apiKeyHex, host, urlPath, method, now = Date.now(), nonce = crypto.randomBytes(16) }) {
  const normalizedApiId = String(apiId ?? '')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .trim();
  if (!normalizedApiId) throw new Error('HMAC API ID is required.');

  const key = decodeSecret(apiKeyHex);
  const timestamp = String(now);
  const k1 = hm(key, nonce);
  const k2 = hm(k1, Buffer.from(timestamp));
  const k3 = hm(k2, Buffer.from('vcode_request_version_1'));
  const canonical = `id=${normalizedApiId}&host=${host}&url=${urlPath}&method=${String(method).toUpperCase()}`;
  const sig = hm(k3, Buffer.from(canonical)).toString('hex');
  return `VERACODE-HMAC-SHA-256 id=${normalizedApiId},ts=${timestamp},nonce=${nonce.toString('hex')},sig=${sig}`;
}
