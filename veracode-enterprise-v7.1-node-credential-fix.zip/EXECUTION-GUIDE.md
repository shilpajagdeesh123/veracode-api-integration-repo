# V7.1 Execution Guide

1. Extract the ZIP into the repository root.
2. Confirm `.github` and `veracode-enterprise-node` are sibling folders.
3. Open the repository root in the Copilot-enabled IDE.
4. Verify Node.js: `node --version` (18 or later).
5. Select the `veracode-agent` custom agent.
6. Use Agent mode and enter `Start Veracode API scan.`
7. Approve the command `node ./veracode-enterprise-node/src/index.js`.
8. On first run, enter the HMAC API ID and hidden API key in the terminal.
9. Select project/module or existing package mode.
10. Wait for upload, scan polling, and result generation.
11. Review `results.csv`; use `results.json` for remediation.
12. Select `veracode-remediation-agent` and request remediation for the selected project/module.

## Manual run

From the repository root:

```text
node ./veracode-enterprise-node/src/index.js
```

## Troubleshooting

- `node is not recognized`: Node.js is not available in PATH; use the organization-approved Node installation.
- Authentication error: remove only an invalid local `config/veracode-secrets.json` and rerun.
- No project found: confirm the repository contains `pom.xml`, `angular.json`, `package.json`, or supported mainframe source files.
- Scan timeout: increase `max_scan_minutes` in `config/scanner.json`.
