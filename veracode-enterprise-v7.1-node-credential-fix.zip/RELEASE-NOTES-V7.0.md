# Veracode Enterprise V7.0

- Replaced Go/native executable implementation with Node.js source.
- Requires Node.js 18+ already available; no installation performed by the package.
- Uses built-in Node.js modules only; no `npm install` required.
- Avoids SmartScreen warnings associated with downloaded unsigned custom executables.
- Retains hidden HMAC credential input, default `api.veracode.com`, Pipeline Scan upload/polling, JSON/CSV outputs, GitHub Copilot agents, mainframe `src` output layout, and remediation paths.
