---
name: veracode-remediation
description: Analyze raw Veracode Pipeline Scan results.json, trace the affected source/data flow, apply safe CWE-specific fixes, validate behavior, and generate remediation evidence.
---

# Veracode Remediation Skill

## Purpose

Use this skill when the task is to remediate vulnerabilities discovered by
Veracode Pipeline Scan.

The objective is not merely to make code look safer. The objective is to make the
smallest technically correct change that addresses the actual Veracode-reported
data flow and survives a subsequent Veracode re-scan.

---

# 1. Source of truth

Always start from the raw Pipeline Scan file:

`.github/Output/<target>/<scan-folder>/results.json`

This file is authoritative.

Do not substitute:
- `results.csv`
- `veracode-findings.json`
- `veracode-findings.csv`
- manually typed finding summaries

when `results.json` exists.

Derived files can be used for navigation only.

Pipeline Scan normally emits detailed findings in `results.json`. Veracode treats
this file as the scan-result artifact and it can also be used as a scan baseline.

---

# 2. Selecting the correct results.json

When a target is provided:

1. Navigate to `.github/Output/<target>/`.
2. Find the newest completed scan directory.
3. Prefer a directory whose `scan-status.json` contains:
   `pipeline_scan_status = SUCCESS`.
4. Use the `results.json` from that exact directory.

When multiple scans exist on one day, prefer the newest timestamped scan folder.

Do not combine findings from different scans unless the user explicitly requests a
comparison.

Record the selected results path in `remediation-report.md`.

Create remediation evidence under:

`.github/remediation/<target>/<YYYY-MM-DD>/`

If the date directory already contains an earlier remediation run, create an
`<HHMMSS>` child directory. Never write remediation evidence into
`.github/Output`; that directory is scan evidence only.

---

# 3. Parse findings defensively

Veracode result schemas can contain nested structures and field names can vary by
scan/client version.

For each finding, extract all available evidence, including where present:

- issue/finding/flaw ID
- CWE ID
- severity
- title/category
- module
- source file
- line number
- function/method/procedure
- source
- sink
- description
- remediation text
- data path
- call stack
- stack dumps
- attack vector/context
- annotations
- status

Do not fabricate missing fields.

If a field is absent, write `Not present in results.json` instead of guessing.

---

# 4. Finding-by-finding workflow

For each finding:

## Step A — Establish identity

Capture:
- finding ID
- CWE
- severity
- affected file
- affected method
- line
- module

Use these values to prevent accidentally remediating a different finding.

## Step B — Locate the risky operation

Identify the security-sensitive operation reported by Veracode.

Examples:
- SQL execution
- HTML/DOM output
- HTTP response header
- logging API
- filesystem path operation
- OS command execution
- redirect
- LDAP/XPath expression
- deserialization
- cryptographic operation

The reported line can be the sink rather than the true root cause.

## Step C — Trace the data flow

Inspect only the code required to understand the finding.

Trace:

`untrusted source -> transformations -> validation/sanitization -> sink`

Follow:
- caller
- callee
- service
- controller/API layer
- DAO/repository
- utility/helper
- shared security wrapper

only when relevant.

Do not scan unrelated source simply to expand context.

## Step D — Identify root cause

Determine why Veracode considers the path unsafe.

Examples:
- missing output encoding
- string-built SQL
- CR/LF reaching a header/log
- user-controlled path
- shell interpolation
- unsafe deserialization
- trust-bypass API
- wrong validation layer
- validation performed after sink
- incomplete canonicalization
- incorrect context-specific encoder

## Step E — Choose the least-invasive correct remediation

Prefer:
1. framework-native safe API;
2. parameterization;
3. context-aware encoding;
4. strict allowlist validation;
5. safe library primitive;
6. centralized helper only when repeated patterns justify it.

Avoid:
- blanket character stripping;
- catch-and-ignore;
- suppressions;
- generic regex sanitizers;
- changing only the Veracode line without addressing the data path;
- disabling logging/security checks;
- returning hard-coded values;
- broad refactoring unrelated code.

## Step F — Apply change

Modify the smallest reasonable source set.

Preserve:
- method signatures where possible;
- API behavior;
- database semantics;
- error behavior;
- logging intent;
- authentication/authorization;
- existing tests.

## Step G — Validate

Run the narrowest reliable validation first:

1. compile affected module;
2. unit tests for changed code;
3. module test suite;
4. project integration tests where appropriate.

If tests cannot run, state exactly why.

## Step H — Report

Write remediation evidence before moving to the next finding.

---

# 5. CWE remediation playbook

## CWE-79 / CWE-80 — Cross-Site Scripting

Goal:
Prevent untrusted data from being interpreted as executable markup/script.

For Angular:
- prefer interpolation and property binding;
- use framework templating rather than direct DOM HTML insertion;
- avoid `innerHTML` for untrusted values;
- do not use `bypassSecurityTrustHtml`, `bypassSecurityTrustScript`,
  `bypassSecurityTrustUrl`, or related bypass APIs as a remediation;
- preserve Angular sanitization;
- apply context-specific encoding when output leaves Angular's protected contexts.

For Java server-rendered content:
- use the correct encoder for HTML body, attribute, JavaScript, URL, or CSS context;
- do not use one generic HTML encoder for all contexts.

Never remediate XSS by globally deleting `<`, `>`, quotes, or script text.

---

## CWE-89 — SQL Injection

Preferred:
- PreparedStatement
- named parameters
- JPA/ORM bind variables

Never concatenate untrusted values into SQL.

For dynamic identifiers such as column/order names:
- parameter binding normally cannot bind identifiers;
- map external values to an explicit allowlist of known identifiers.

Do not use SQL escaping as the primary defense.

---

## CWE-113 — CRLF / HTTP Response Splitting

Prevent untrusted CR (`\r`) or LF (`\n`) from entering response headers.

Preferred:
- framework-safe response APIs;
- reject invalid header values;
- strict allowlist validation where the value has a defined format.

Do not silently normalize arbitrary attacker-controlled header content into a
different trusted value unless business semantics require that behavior.

---

## CWE-117 — Improper Output Neutralization for Logs

Prevent untrusted control characters from forging/multiplying log entries.

Preferred:
- structured logging with parameterized fields;
- centralized log-value neutralization if required by the framework/runtime;
- neutralize CR/LF/control characters while preserving diagnostic meaning.

Do not:
- remove the log statement;
- log a hard-coded placeholder for every user value;
- disable security logging.

Avoid double encoding if a central logging layer already neutralizes values.

---

## CWE-22 — Path Traversal

Preferred workflow:
1. establish trusted base directory;
2. resolve candidate path against base;
3. normalize/canonicalize;
4. verify resolved path remains inside trusted base;
5. reject violations.

If only predefined filenames are allowed, use an allowlist.

Do not rely on removing `../` strings.

---

## CWE-78 — OS Command Injection

Preferred:
- avoid the shell;
- invoke a fixed executable directly;
- pass arguments as separate values;
- map user choices to predefined commands/arguments.

Do not concatenate untrusted values into shell command strings.

---

## CWE-601 — Open Redirect

Use:
- relative destinations;
- explicit destination allowlists;
- server-side mappings from logical destination IDs to trusted URLs.

Do not use substring/domain-suffix checks that can be bypassed.

---

## CWE-502 — Unsafe Deserialization

Use:
- safer serialization formats where possible;
- explicit type allowlists;
- framework/library controls that prevent arbitrary type instantiation.

Do not deserialize untrusted native object streams without strict controls.

---

## Cryptography findings

Do not mechanically replace algorithms without understanding compatibility.

Check:
- stored data format;
- protocol requirements;
- key sizes;
- migration strategy;
- external consumers;
- backward compatibility.

If a cryptographic change affects persisted/interface data, report the migration
requirement instead of performing an unsafe local-only change.

---

# 6. Java-specific remediation rules

For Java applications:

- prefer standard/framework APIs already used by the repository;
- do not introduce a new security library when an existing approved library solves
  the problem;
- preserve Spring/Jakarta/JPA conventions;
- inspect parent POM/dependency management only when a library fix requires it;
- use `PreparedStatement` or framework parameter binding for SQL;
- use parameterized logging APIs rather than concatenated log strings when useful;
- avoid modifying generated sources.

For Maven validation, prefer:

`mvn -pl <module> -am test`

or the repository's Maven Wrapper when present.

---

# 7. Angular/TypeScript-specific remediation rules

For Angular:

- trust Angular's normal interpolation/property-binding protections;
- avoid direct DOM APIs for untrusted data;
- avoid sanitizer bypass functions;
- verify URL/resource URL contexts separately from HTML contexts;
- preserve reactive/template behavior;
- run the repository's actual lint/test/build commands if available.

Do not "fix" a finding by disabling template validation or sanitizer behavior.

---

# 8. Mainframe/COBOL guidance

When findings map to COBOL/mainframe source:

- preserve fixed/free-format source conventions;
- preserve copybook layouts and interface contracts;
- trace data across copybooks, programs, CICS/DB2/file operations as required;
- avoid changing record structures merely to silence a finding;
- preserve PIC definitions unless the security fix specifically requires a
  validated interface change;
- validate DB2 query parameterization/dynamic SQL carefully;
- document any remediation that requires coordinated copybook/interface changes.

Do not apply Java-centric fixes to COBOL source.

---

# 9. Multi-module applications

If the finding is in one module but the source enters through another:

Example:

`REST controller -> service -> shared library -> DAO sink`

inspect the whole confirmed path.

Prefer placing validation/encoding at the correct security boundary, not merely at
the easiest file.

If changing a shared module:
- identify downstream callers;
- assess compatibility;
- run broader tests.

---

# 10. Existing Veracode package mode

When the scan used:

`EXISTING VERACODE PACKAGE`

remember that `results.json` describes the binaries/source packaged in that
specific artifact.

After source remediation:
1. rebuild affected artifacts;
2. recreate the Veracode package using the same UI packaging structure;
3. run a fresh scan;
4. compare results.

Do not rescan the old ZIP and expect source fixes to appear.

---

# 11. Handling uncertain remediation

If a secure automated fix cannot be determined confidently:

Do not make a speculative patch.

Instead classify the finding in `remediation-report.md` as:

`MANUAL_REVIEW_REQUIRED`

Include:
- why the root cause is ambiguous;
- what code/data path was inspected;
- what additional information is needed;
- safe remediation options.

A correct partial remediation is better than a risky automatic change.

---

# 12. Remediation report format

Create `remediation-report.md` beside the authoritative `results.json`.

Use:

## Scan input
- Target:
- Scan directory:
- Authoritative results:
- Pipeline scan ID if available:

## Summary
- Findings reviewed:
- Findings remediated:
- Manual review required:
- Build result:
- Test result:

## Finding <ID>
- CWE:
- Severity:
- Module:
- File:
- Line:
- Method:
- Source:
- Sink:
- Data flow:
- Root cause:
- Remediation:
- Files changed:
- Validation:
- Status:

Status values:
- `REMEDIATED_PENDING_VERACODE_RESCAN`
- `MANUAL_REVIEW_REQUIRED`
- `NO_SAFE_AUTOMATED_FIX`

Never use `VERIFIED` without a subsequent Veracode scan.

---

# 13. Completion criteria

The remediation task is complete only when:

- every selected result finding has been reviewed;
- each finding has a remediation or explicit manual-review status;
- code compiles where applicable;
- relevant tests have been executed where possible;
- `remediation-report.md` is written;
- no scan/result file was modified;
- the user is told to run a fresh Veracode scan.

A fresh Veracode scan is the final verification step.


# 6. Remediation output structure

For the selected target, create:

```text
.github/remediation/<target>/<YYYY-MM-DD>/
├── remediation-report.md
├── remediation.patch              # when a patch can be generated
├── changed-files.txt
└── validation.log                  # commands and outcomes
```

If the date folder is already populated, use a timestamp child folder.
The report must reference the authoritative source file, for example:

```text
.github/Output/<target>/<scan-folder>/results.json
```

Do not edit, relocate, or replace `results.json`.
