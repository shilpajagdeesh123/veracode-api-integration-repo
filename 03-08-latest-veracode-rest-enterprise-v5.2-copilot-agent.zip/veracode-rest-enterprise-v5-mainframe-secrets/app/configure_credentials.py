#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import json
import os
from pathlib import Path
import sys

PLACEHOLDER_PREFIXES = ("REPLACE_", "YOUR_", "ENTER_")


def is_missing(value: object) -> bool:
    text = str(value or "").strip()
    return not text or text.upper().startswith(PLACEHOLDER_PREFIXES)


def load_existing(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"Unable to read {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(f"Credential file must contain a JSON object: {path}")
    return data


def atomic_write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate or configure Veracode HMAC credentials.")
    parser.add_argument("--tool-home", required=True)
    args = parser.parse_args()

    tool_home = Path(args.tool_home.strip().strip('"')).resolve()
    secret_path = tool_home / "config" / "veracode-secrets.json"

    try:
        data = load_existing(secret_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    api_id = str(data.get("api_id", "")).strip()
    api_key = str(data.get("api_key", "")).strip()

    if not is_missing(api_id) and not is_missing(api_key):
        print(f"Veracode HMAC credentials found in: {secret_path}")
        return 0

    print()
    print("Veracode HMAC credentials are not configured.")
    print("Enter them in this terminal. The API key input is hidden.")
    print("Default API host: api.veracode.com")
    print()

    while is_missing(api_id):
        api_id = input("Veracode HMAC API ID: ").strip()
        if is_missing(api_id):
            print("API ID cannot be empty.")

    while is_missing(api_key):
        api_key = getpass.getpass("Veracode HMAC API Key: ").strip()
        if is_missing(api_key):
            print("API key cannot be empty.")

    # Veracode HMAC keys are hexadecimal. Fail early on accidental copy errors.
    try:
        bytes.fromhex(api_key)
    except ValueError:
        print("ERROR: The Veracode HMAC API key must be hexadecimal.", file=sys.stderr)
        return 3

    atomic_write(secret_path, {
        "api_id": api_id,
        "api_key": api_key,
        "api_host": "api.veracode.com",
    })

    print()
    print(f"Credentials saved to: {secret_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
