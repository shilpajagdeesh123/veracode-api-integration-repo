@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "TOOL_HOME=%~dp0"
set "RUNTIME_DIR=%TOOL_HOME%runtime\python"
set "TMP_DIR=%TOOL_HOME%runtime\download"
set "PY_ZIP=%TMP_DIR%\python-3.13.14-embed-amd64.zip"

set "PY_URL=https://www.python.org/ftp/python/3.13.14/python-3.13.14-embed-amd64.zip"
set "PY_SHA256=90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907"

if exist "%RUNTIME_DIR%\python.exe" (
    echo Python runtime already available:
    "%RUNTIME_DIR%\python.exe" --version
    exit /b 0
)

where curl.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: curl.exe is required for first-time runtime bootstrap.
    echo Ask your desktop engineering team to place the official Python embeddable ZIP at:
    echo   %PY_ZIP%
    exit /b 2
)

where certutil.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: certutil.exe is required to verify the Python SHA-256.
    exit /b 2
)

where tar.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: tar.exe is required to extract the Python embeddable ZIP.
    exit /b 2
)

if not exist "%TMP_DIR%" mkdir "%TMP_DIR%"
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%"

if not exist "%PY_ZIP%" (
    echo Downloading official Python 3.13.14 Windows embeddable runtime...
    curl.exe --fail --location --output "%PY_ZIP%" "%PY_URL%"
    if errorlevel 1 (
        echo ERROR: Python download failed.
        exit /b 3
    )
)

echo Verifying Python runtime SHA-256...
for /f "skip=1 tokens=* delims=" %%H in ('certutil.exe -hashfile "%PY_ZIP%" SHA256 ^| findstr /R /V /C:"hash of file" /C:"CertUtil"') do (
    set "ACTUAL_HASH=%%H"
    goto :hashdone
)
:hashdone
set "ACTUAL_HASH=%ACTUAL_HASH: =%"

if /I not "%ACTUAL_HASH%"=="%PY_SHA256%" (
    echo ERROR: Python runtime SHA-256 mismatch.
    echo Expected: %PY_SHA256%
    echo Actual:   %ACTUAL_HASH%
    del /q "%PY_ZIP%" >nul 2>&1
    exit /b 4
)

echo Extracting Python locally. No administrator rights are required...
tar.exe -xf "%PY_ZIP%" -C "%RUNTIME_DIR%"
if errorlevel 1 (
    echo ERROR: Python extraction failed.
    exit /b 5
)

if not exist "%RUNTIME_DIR%\python.exe" (
    echo ERROR: python.exe was not found after extraction.
    exit /b 5
)

echo.
echo Python runtime initialized successfully:
"%RUNTIME_DIR%\python.exe" --version
exit /b 0
