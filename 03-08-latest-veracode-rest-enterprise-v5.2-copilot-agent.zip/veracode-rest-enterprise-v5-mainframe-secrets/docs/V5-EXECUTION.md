# V5.1 Windows execution

Run the single entry point:

```bat
veracode-agent.bat
```

The agent automatically checks or performs:

1. Local bundled Python runtime setup without administrator installation.
2. Veracode HMAC API credential presence.
3. Interactive terminal collection of missing API ID and API key.
4. Credential storage in `config\veracode-secrets.json`.
5. Execution of `run-veracode.bat`.

The API host is fixed by default to:

```text
api.veracode.com
```

Choose one scan mode when prompted:

```text
1. PROJECT
2. MODULE
3. EXISTING VERACODE PACKAGE
```

Scan evidence is generated under:

```text
.github\Output\<target>\<date-or-timestamp>\
```

`results.csv` is generated for human readability. The remediation agent must use
only the raw `results.json` as the authoritative vulnerability input.

Remediation evidence is generated separately under:

```text
.github\remediation\<target>\<YYYY-MM-DD>\
```
