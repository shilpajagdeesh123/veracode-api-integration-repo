# Why Pipeline Scan may not match the Veracode UI

Pipeline Scan is a development scan and should not be treated as an exact replica
of the official Veracode Platform/UI scan.

Differences can occur because of:

- different submitted artifacts/modules;
- Platform flaw matching/history;
- mitigations and accepted risk;
- official application policy evaluation;
- SCA/open-source component results;
- Platform-specific processing and metadata.

## Recommended use

Use V4.3 for:

```text
pre-commit detection
-> Copilot remediation
-> development re-scan
-> development gate
```

Use the formal Veracode Upload & Scan for:

```text
official UI result
policy compliance
release gate
audit/compliance evidence
```

If closer result alignment is required, submit the same packaging/module set in
both development and official scans.
