# Troubleshooting V4.1

## `OSError: [Errno 22] Invalid argument` while opening `scanner.json`

V4 passed `%~dp0` directly to Python. `%~dp0` always ends with a backslash.
On Windows, a quoted command-line argument ending with `\` can be parsed
incorrectly by a native executable.

V4.1 normalizes the tool directory first:

```bat
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
```

It also verifies that this file exists before starting Python:

```text
config\scanner.json
```

### Validate before running

From the package directory:

```bat
dir config\scanner.json
```

Then:

```bat
run-veracode.bat
```

Expected:

```text
Tool home:
  C:\...\veracode-rest-enterprise-v4.1-python
```

There should be no stray quote at the end.

### Direct Python path test

```bat
runtime\python\python.exe -c "from pathlib import Path; p=Path(r'config\scanner.json').resolve(); print(p); print(p.exists())"
```

Expected final line:

```text
True
```
