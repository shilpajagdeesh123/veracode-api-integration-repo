# Veracode credential setup

Run:

```bat
veracode-agent.bat
```

When `config\veracode-secrets.json` is missing or contains placeholders, the
agent asks for the Veracode HMAC API ID and API key in the terminal. The API key
input is hidden. The file is then created as:

```json
{
  "api_id": "<entered-api-id>",
  "api_key": "<entered-api-key>",
  "api_host": "api.veracode.com"
}
```

The secret file is excluded by `.gitignore`. Do not commit it.
