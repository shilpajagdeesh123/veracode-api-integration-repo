@echo off
setlocal EnableExtensions

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

echo ==========================================================
echo  Veracode Enterprise Agent
echo ==========================================================
echo.

if not exist "%PYTHON_EXE%" (
    echo Python runtime was not found.
    echo Starting local no-admin Python setup...
    echo.
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        exit /b 2
    )
)

"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" --tool-home "%TOOL_HOME%"
if errorlevel 1 (
    echo.
    echo ERROR: Veracode credential setup failed.
    exit /b 3
)

echo.
echo Starting run-veracode.bat...
echo.
call "%TOOL_HOME%\run-veracode.bat"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Veracode agent completed successfully.
) else (
    echo Veracode agent finished with exit code %EXIT_CODE%.
)
exit /b %EXIT_CODE%
