

## V4.5 — results.json-driven Copilot remediation

V4.5 adds a GitHub Copilot project skill:

```text
.github/
├── agents/
│   └── veracode-remediation-agent.md
└── skills/
    └── veracode-remediation/
        └── SKILL.md
```

The remediation workflow now treats the raw Pipeline Scan `results.json` as the
authoritative input. Normalized JSON/CSV outputs remain available for reporting,
but are not the primary remediation source.

Recommended Copilot prompt:

```text
Remediate the latest Veracode findings for customer-service using results.json.
```


## V5 — Mainframe + secret-file credentials

V5 adds:

- automatic mainframe/COBOL discovery and source packaging;
- HMAC credentials loaded from `config/veracode-secrets.json`;
- helper `create-secret-file.bat`;
- no need to set credential environment variables;
- PROJECT / MODULE / EXISTING VERACODE PACKAGE modes retained;
- JSON + CSV output retained;
- raw `results.json` remains the authoritative Copilot remediation input.


## V5.1 — Veracode agent bootstrap

Use the new single entry point:

```bat
veracode-agent.bat
```

It performs this sequence automatically:

1. Checks for the bundled local Python runtime.
2. Runs `setup-runtime.bat` when Python is missing.
3. Checks `config\veracode-secrets.json`.
4. Prompts in the terminal for the HMAC API ID and hidden API key when missing.
5. Saves the credentials with the default host `api.veracode.com`.
6. Starts `run-veracode.bat`.
7. Generates `results.csv` for readability while keeping `results.json` as the only authoritative remediation input.

Remediation evidence is created under:

```text
.github\remediation\<project-name>\<YYYY-MM-DD>\
```

A timestamp child folder is used when the date folder already contains a prior run.

## V5.2 — Repository-root GitHub Copilot scan agent

The `.github` directory is intentionally outside this enterprise package folder.
From the repository root, select `veracode-agent` in GitHub Copilot and use:

```text
Start Veracode API scan.
```

Copilot invokes `veracode-agent.bat` in an interactive Windows terminal. Never
paste HMAC credentials into Copilot chat; credential entry occurs only in the
terminal, with the API key hidden.
