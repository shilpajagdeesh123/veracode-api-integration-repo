@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

if exist "%TOOL_HOME%\config\veracode-secrets.json" (
  echo Secret file already exists:
  echo   %TOOL_HOME%\config\veracode-secrets.json
  exit /b 0
)

copy /Y "%TOOL_HOME%\config\veracode-secrets.template.json" "%TOOL_HOME%\config\veracode-secrets.json" >nul
if errorlevel 1 (
  echo ERROR: Unable to create secret file.
  exit /b 1
)

echo Created:
echo   %TOOL_HOME%\config\veracode-secrets.json
echo.
echo Edit api_id and api_key before running run-veracode.bat.
exit /b 0
