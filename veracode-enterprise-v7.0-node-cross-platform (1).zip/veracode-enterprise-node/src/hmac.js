import crypto from 'node:crypto';

function hm(key, data) { return crypto.createHmac('sha256', key).update(data).digest(); }
export function authorizationHeader({ apiId, apiKeyHex, host, urlPath, method, now = Date.now(), nonce = crypto.randomBytes(16) }) {
  const cleaned = String(apiKeyHex).trim();
  if (!/^[0-9a-fA-F]+$/.test(cleaned) || cleaned.length % 2 !== 0) throw new Error('HMAC API key must be valid hexadecimal');
  const key = Buffer.from(cleaned, 'hex');
  const timestamp = String(now);
  const k1 = hm(key, nonce);
  const k2 = hm(k1, Buffer.from(timestamp));
  const k3 = hm(k2, Buffer.from('vcode_request_version_1'));
  const canonical = `id=${apiId}&host=${host}&url=${urlPath}&method=${String(method).toUpperCase()}`;
  const sig = hm(k3, Buffer.from(canonical)).toString('hex');
  return `VERACODE-HMAC-SHA-256 id=${apiId},ts=${timestamp},nonce=${nonce.toString('hex')},sig=${sig}`;
}
