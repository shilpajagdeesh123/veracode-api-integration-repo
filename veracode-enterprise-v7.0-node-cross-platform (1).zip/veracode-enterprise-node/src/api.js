import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { authorizationHeader } from './hmac.js';
import { sleep } from './utils.js';

export class VeracodeClient {
  constructor({ host, apiId, apiKey }) { this.host = host; this.apiId = apiId; this.apiKey = apiKey; }
  async request(method, urlPath, body, extraHeaders = {}) {
    const headers = {
      Authorization: authorizationHeader({ apiId: this.apiId, apiKeyHex: this.apiKey, host: this.host, urlPath, method }),
      Accept: 'application/json',
      'User-Agent': 'veracode-enterprise-node/7.0',
      ...extraHeaders
    };
    let payload;
    if (body !== undefined && body !== null) { payload = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body); if (!headers['Content-Type']) headers['Content-Type'] = 'application/json'; }
    const response = await fetch(`https://${this.host}${urlPath}`, { method, headers, body: payload, signal: AbortSignal.timeout(300000) });
    const text = await response.text();
    if (!response.ok) throw new Error(`Veracode API HTTP ${response.status}: ${text}`);
    return text.trim() ? JSON.parse(text) : {};
  }
  async uploadSegment(scanId, index, filePath) {
    const boundary = `----VeracodeNode${crypto.randomBytes(12).toString('hex')}`;
    const file = fs.readFileSync(filePath);
    const prefix = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${path.basename(filePath)}"\r\nContent-Type: application/octet-stream\r\n\r\n`);
    const suffix = Buffer.from(`\r\n--${boundary}--\r\n`);
    return this.request('PUT', `/pipeline_scan/v1/scans/${scanId}/segments/${index}`, Buffer.concat([prefix, file, suffix]), { 'Content-Type': `multipart/form-data; boundary=${boundary}` });
  }
}

function splitFile(filePath, segments) {
  const data = fs.readFileSync(filePath); const files = []; const base = Math.floor(data.length / segments); let remainder = data.length % segments; let offset = 0;
  for (let i = 0; i < segments; i++) {
    const size = base + (remainder-- > 0 ? 1 : 0); const p = `${filePath}.segment-${String(i).padStart(4, '0')}`;
    fs.writeFileSync(p, data.subarray(offset, offset + size)); offset += size; files.push(p);
  }
  return files;
}

export async function runPipelineScan(config, secrets, artifact, projectName) {
  const stat = fs.statSync(artifact);
  const hash = crypto.createHash('sha256').update(fs.readFileSync(artifact)).digest('hex');
  const client = new VeracodeClient({ host: config.api_host, apiId: secrets.api_id, apiKey: secrets.api_key });
  const created = await client.request('POST', '/pipeline_scan/v1/scans', {
    binary_name: path.basename(artifact), binary_size: stat.size, binary_hash: hash,
    project_name: projectName, dev_stage: config.development_stage || 'DEVELOPMENT'
  });
  const scanId = String(created.scan_id || '');
  const segmentCount = Number(created.binary_segments_expected || 0);
  if (!scanId || segmentCount < 1) throw new Error('Invalid scan creation response');
  const segments = splitFile(artifact, segmentCount);
  try {
    for (let i = 0; i < segments.length; i++) { console.log(`Uploading segment ${i + 1}/${segments.length}`); await client.uploadSegment(scanId, i, segments[i]); }
    await client.request('PUT', `/pipeline_scan/v1/scans/${scanId}`, { scan_status: 'STARTED' });
    const deadline = Date.now() + Number(config.max_scan_minutes || 60) * 60000;
    let details = {};
    while (Date.now() < deadline) {
      await sleep(Number(config.poll_seconds || 20) * 1000);
      details = await client.request('GET', `/pipeline_scan/v1/scans/${scanId}`);
      const status = String(details.scan_status || '').toUpperCase(); console.log(`Scan status: ${status}`);
      if (status === 'SUCCESS') break;
      if (['ERROR', 'FAILED', 'CANCELLED'].includes(status)) throw new Error(`Scan ended with ${status}`);
    }
    if (String(details.scan_status || '').toUpperCase() !== 'SUCCESS') throw new Error('Scan timeout');
    const results = await client.request('GET', `/pipeline_scan/v1/scans/${scanId}/findings`);
    return { results, metadata: { scan_id: scanId, binary_size: stat.size, binary_hash_sha256: hash, scan_status: 'SUCCESS', completed: new Date().toISOString() } };
  } finally { for (const p of segments) { try { fs.unlinkSync(p); } catch {} } }
}
