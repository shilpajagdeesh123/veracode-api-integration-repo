import fs from 'node:fs';
import path from 'node:path';
import { ask, readSecret } from './terminal.js';
import { readJson, writeJson } from './utils.js';

function valid(s) {
  return Boolean(s?.api_id && s?.api_key && !String(s.api_id).toUpperCase().startsWith('REPLACE_') && !String(s.api_key).toUpperCase().startsWith('REPLACE_'));
}

export async function loadOrPromptCredentials(home) {
  const file = path.join(home, 'config', 'veracode-secrets.json');
  const existing = readJson(file);
  if (valid(existing)) return { ...existing, api_host: existing.api_host || 'api.veracode.com' };
  console.log('Veracode HMAC credentials are not configured.');
  const api_id = await ask('HMAC API ID');
  const api_key = await readSecret('HMAC API key (hidden)');
  const secrets = { api_id: api_id.trim(), api_key: api_key.trim(), api_host: 'api.veracode.com' };
  if (!valid(secrets)) throw new Error('API ID or API key is empty or invalid');
  writeJson(file, secrets, 0o600);
  try { if (process.platform === 'win32') fs.chmodSync(file, 0o600); } catch {}
  console.log(`Credentials saved locally to ${file}`);
  return secrets;
}
