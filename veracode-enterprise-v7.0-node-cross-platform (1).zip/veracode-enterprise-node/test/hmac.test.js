import test from 'node:test';
import assert from 'node:assert/strict';
import { authorizationHeader } from '../src/hmac.js';

test('HMAC header is deterministic with fixed timestamp and nonce', () => {
  const header = authorizationHeader({ apiId: 'abc', apiKeyHex: '00112233445566778899aabbccddeeff', host: 'api.veracode.com', urlPath: '/pipeline_scan/v1/scans', method: 'POST', now: 1700000000000, nonce: Buffer.alloc(16, 1) });
  assert.match(header, /^VERACODE-HMAC-SHA-256 id=abc,ts=1700000000000,nonce=01010101010101010101010101010101,sig=[0-9a-f]{64}$/);
});
