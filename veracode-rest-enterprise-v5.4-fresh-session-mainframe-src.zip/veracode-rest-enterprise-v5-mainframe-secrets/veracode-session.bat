@echo off
setlocal EnableExtensions

rem ================================================================
rem Veracode Enterprise isolated execution session
rem This script runs inside the NEW terminal opened by veracode-agent.bat.
rem It does not delete credentials, prior outputs, remediation evidence, or logs.
rem ================================================================

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

rem Clear only per-process variables that this package may use. This does not
rem change machine/user variables and does not delete any file.
set "VERACODE_PROJECT="
set "VERACODE_MODULE="
set "VERACODE_SCAN_ID="
set "VERACODE_OUTPUT_DIR="
set "VERACODE_TARGET="
set "VERACODE_FRESH_SESSION=1"

cls
echo ==========================================================
echo  Veracode Enterprise Agent - Fresh Session
echo ==========================================================
echo.
echo Tool home:
echo   %TOOL_HOME%
echo.
echo This run preserves:
echo   - config\veracode-secrets.json
echo   - all previous .github\Output reports
echo   - all previous .github\remediation evidence
echo   - existing logs and package caches
echo.

if not exist "%PYTHON_EXE%" (
    echo Python runtime was not found.
    echo Starting local no-admin Python setup...
    echo.
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        exit /b 2
    )
)

"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" --tool-home "%TOOL_HOME%"
if errorlevel 1 (
    echo.
    echo ERROR: Veracode credential setup failed.
    exit /b 3
)

echo.
echo Starting run-veracode.bat...
echo.
call "%TOOL_HOME%\run-veracode.bat"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Veracode agent completed successfully.
) else (
    echo Veracode agent finished with exit code %EXIT_CODE%.
)

echo.
echo Press any key to close this fresh Veracode terminal.
pause >nul
exit /b %EXIT_CODE%
