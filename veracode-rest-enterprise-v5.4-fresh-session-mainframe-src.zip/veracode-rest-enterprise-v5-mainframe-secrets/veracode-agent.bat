@echo off
setlocal EnableExtensions

rem ================================================================
rem Veracode Enterprise fresh-terminal launcher
rem Every invocation starts the real workflow in a NEW cmd.exe session.
rem No credentials, scan results, remediation files, logs, or caches are deleted.
rem ================================================================

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "SESSION_BAT=%TOOL_HOME%\veracode-session.bat"

if not exist "%SESSION_BAT%" (
    echo.
    echo ERROR: Fresh-session script was not found:
    echo   %SESSION_BAT%
    exit /b 10
)

echo ==========================================================
echo  Veracode Enterprise Agent Launcher
echo ==========================================================
echo.
echo Starting a new terminal session for this scan...
echo Existing credentials and previous reports will be preserved.
echo.

rem /WAIT allows the calling Copilot/terminal process to receive the final exit code.
rem /D disables AutoRun commands so the new terminal starts with predictable cmd behavior.
start "Veracode Enterprise Scan" /wait "%ComSpec%" /D /C ""%SESSION_BAT%""
set "EXIT_CODE=%ERRORLEVEL%"

if "%EXIT_CODE%"=="0" (
    echo.
    echo Fresh Veracode session completed successfully.
) else (
    echo.
    echo Fresh Veracode session finished with exit code %EXIT_CODE%.
)

exit /b %EXIT_CODE%
