---
name: veracode-agent
description: Run the packaged Windows Veracode scan bootstrap safely from GitHub Copilot, including local Python setup and terminal-only HMAC credential configuration.
---

# Veracode Agent Skill

## Purpose

Use this skill when a developer asks GitHub Copilot to start the repository's
Veracode API scan.

The enterprise package owns the full execution workflow. Copilot must invoke the
package rather than duplicating its Python setup, credential handling, HMAC
logic, API requests, packaging rules, or result processing.

## Repository layout

The `.github` directory is at the repository root and is outside the enterprise
package directory:

```text
<repository-root>/
├── .github/
│   ├── agents/
│   │   ├── veracode-agent.md
│   │   └── veracode-remediation-agent.md
│   └── skills/
│       ├── veracode-agent/
│       │   └── SKILL.md
│       └── veracode-remediation/
│           └── SKILL.md
└── veracode-rest-enterprise-v5-mainframe-secrets/
    ├── veracode-agent.bat
    ├── setup-runtime.bat
    ├── run-veracode.bat
    ├── app/
    ├── config/
    └── runtime/
```

## Workflow

### 1. Locate the enterprise entry point

From the repository root, identify the directory containing:

- `veracode-agent.bat`
- `setup-runtime.bat`
- `run-veracode.bat`
- `app\configure_credentials.py`

Do not choose a batch file from build output, backup, archive, or remediation
folders.

### 2. Start a fresh interactive Windows terminal

Run the launcher:

```bat
call "veracode-rest-enterprise-v5-mainframe-secrets\veracode-agent.bat"
```

The launcher must create a new `cmd.exe` process on every run. That new terminal remains interactive because the package may ask for target, scan mode, package path, API ID, and hidden API key. Do not reuse a previously opened scan terminal.

### 3. Allow the package to bootstrap Python

The entry point checks:

`runtime\python\python.exe`

When it is absent, the entry point runs:

`setup-runtime.bat`

This runtime is local to the package and must not require administrator access.
Do not replace this step with a system-wide Python installation unless the user
explicitly redesigns the package.

### 4. Allow secure credential configuration

The package checks:

`config\veracode-secrets.json`

When valid credentials are missing, `configure_credentials.py` prompts in the
terminal for:

- Veracode HMAC API ID;
- Veracode HMAC API key through hidden input.

The package then saves:

```json
{
  "api_id": "<entered in terminal>",
  "api_key": "<entered with hidden input>",
  "api_host": "api.veracode.com"
}
```

The JSON shown above is structural documentation only. Never populate it in
Copilot chat and never reveal actual credential values.

### 5. Start the scan

After runtime and credential validation, `veracode-agent.bat` automatically
calls `run-veracode.bat`.

Do not separately start `run-veracode.bat` unless troubleshooting a confirmed
entry-point problem.

### 6. Preserve result semantics

Scan outputs are written under the repository-root path:

`.github/Output/<project-or-module>/<date-or-timestamp>/`

The raw Veracode `results.json` is authoritative for remediation.

`results.csv` is generated only for readability and spreadsheet review. It must
not replace `results.json` as remediation input.

### 7. Hand off remediation

When blocking findings exist, use:

`.github/agents/veracode-remediation-agent.md`

Remediation evidence must be created under:

`.github/remediation/<project-or-module>/<YYYY-MM-DD>/`

## Fresh terminal rules

- Every invocation of `veracode-agent.bat` must open a new `cmd.exe` session.
- The actual runtime and credential workflow runs from `veracode-session.bat`.
- Do not continue an interrupted scan in an old terminal. Start the agent again.
- Starting fresh does not delete `config\veracode-secrets.json`.
- Starting fresh does not delete prior `.github\Output`, `.github\remediation`, logs, or caches.
- Only temporary environment variables inside the new process are reset. Machine and user environment variables are not changed.

## Credential safety

Never:

- request the API key in Copilot chat;
- place credentials in a prompt or command argument;
- display the secret file;
- commit `config/veracode-secrets.json`;
- copy credentials into logs, reports, patches, or Markdown;
- replace hidden input with visible `set /p` input.

## Failure handling

If execution fails:

1. retain the real exit code;
2. report the visible failing stage;
3. reference the exact script that failed;
4. do not claim that results were generated unless the output files exist;
5. do not fabricate Veracode findings.

## Standard prompt

`Start Veracode API scan.`


## Mainframe output convention

For a discovered mainframe project or module, the scanner must write the scan
result beneath the selected target's `src` path namespace:

```text
.github/Output/<project-or-module>/src/<YYYY-MM-DD>/results.json
.github/Output/<project-or-module>/src/<YYYY-MM-DD>/results.csv
```

If that date already contains `results.json`, use a timestamp child folder.
`results.json` remains the only authoritative remediation input.

The matching remediation path is:

```text
.github/remediation/<project-or-module>/src/<YYYY-MM-DD>/
```
